# react-nodejs-docker-compose
Example project on how to develop project on Docker Compose
